<?php

$polls_db_server = "127.0.0.1";
$polls_db_username = "root";
$polls_db_password = "";
$polls_db_database = "moms_app_v4_database";

?>
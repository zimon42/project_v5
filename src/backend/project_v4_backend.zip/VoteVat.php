<?php

class VoteVat {
	public $voteId;
	public $vatId;
	public $perc;
}

?>
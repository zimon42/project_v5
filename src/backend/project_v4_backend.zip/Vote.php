<?php

class Vote {
	public $id;
	public $pollId;
	public $userPersNumber;
	public $voteDate;
}

?>
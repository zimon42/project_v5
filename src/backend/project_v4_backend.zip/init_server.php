<?php

echo "init_server not working. call create_tables.php and init_vats on their own";
// include_once("create_tables.php");
// include_once("init_vats.php");
// include_once("add_random_votes.php");

?>
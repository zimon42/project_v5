For some reason init_server doesn't work

Call these scripts one by one:
1. create_tables.php
2. init_vats.php
3. add_random_votes.php